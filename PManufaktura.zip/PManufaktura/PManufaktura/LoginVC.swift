//
//  LoginVC.swift
//  PManufaktura
//
//  Created by Reka Vihari on 2018. 02. 15..
//  Copyright © 2018. BME AUT. All rights reserved.
//

import Foundation
import UIKit




class LoginVC: UIViewController{
    
   
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        txtEmail.layer.borderWidth = 1
        txtEmail.layer.borderColor = UIColor.white.cgColor
        txtEmail.layer.cornerRadius = 20
        txtEmail.clipsToBounds = true
        
        txtPassword.layer.borderWidth = 1
        txtPassword.layer.borderColor = UIColor.white.cgColor
        txtPassword.layer.cornerRadius = 20
        txtPassword.clipsToBounds = true
        
        btnLogin.layer.cornerRadius = 20
        btnLogin.clipsToBounds = true
        
    }
    

    
}
